// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// Polymorphic exception class derived from from �std::exception�
class CustomException : public std::exception {
public:
    virtual const char* what() const throw() {
        return " (!) CUSTOM EXCEPTION (!) ";
    }
} customException;

bool do_even_more_custom_application_logic()
{

    // TODO: Throw any standard exception

    // Throw a standard exception.
    throw std::exception(" (!) STANDARD EXCEPTION (!) ");

    std::cout << " Running Even More Custom Application Logic. " << std::endl;

    return true;

}
void do_custom_application_logic()
{

    
    std::cout << " Running Custom Application Logic. " << std::endl;

    //  Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    try 
    {
        //  If the 'do_even_more_application_logic' function runs succesfully,
        if (do_even_more_custom_application_logic())
        {
            //  then output a message saying that the custom application logic succeeded.
            std::cout << " Even More Custom Application Logic Succeeded. " << std::endl;
        }
    }

    //  If an exception is thrown, then catch it.
    catch (const std::exception& e) 
    {
        // and output a message saying that the additional application logic failed. 
        std::cerr << " Additional Custom Application Logic Failed. " << e.what() << std::endl; 
    }

    //  Throw a custom exception derived from std::exception
    //  and catch it explictly in main.
    throw customException;

    std::cout << " Leaving Custom Application Logic. " << std::endl;

}

float divide(float num, float den)
{

    //  Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    //  If the number to be divided by is zero, 
    if (den == 0) {

        //  then throw an error.
        throw std::invalid_argument(" (!) ERROR ATTEMPTING TO DIVIDE BY ZERO (!) ");
    }

    //  Otherwie, if the denominator is not zero,  
    else {
        //  then divide the numerator )'num') by the denominator ('den').
        return (num / den);
    }

}

void do_division() noexcept
{

    //  Create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;

    //  Set the denominator to zero to test the 'divide()' function.
    float denominator = 0;

    //  Try to divide the numerator (set to 10) by the denominator (set to 0).
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }

    // Catch the exception if (when) the an exception is thrown due to
    // the denominator having been set to zero.
    catch (const std::exception& e) {
        std::cerr << " The 'divide()' function failed. " << e.what() << std::endl;
    }

}

int main()
{
    std::cout << " Exceptions Tests! " << std::endl;

    // Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    // Try to run the 'do_division()' and 'do_custom_application_logic()' functions.
    try {
        do_division();
        do_custom_application_logic();
    }

    //  Catch custom exceptions,
    catch (CustomException& e) { 
        
        //  and output a message saying that the code terminated abruptly.
        //  The 'custom exception' specification fcomes from one of the
        //   functions called in the 'try' block.
        std::cerr << " The code terminated abruptly. " << e.what() << std::endl;
    }

    //  Catch standard exceptions, 
    catch (std::exception& e) { 

        //  and output a message saying that the code terminated abruptly.
        //  The 'standard exception' specification fcomes from one of the
        //   functions called in the 'try' block.
        std::cerr << " The code terminated abruptly (standard). " << e.what() << std::endl;
    }

    //  Catch other types of exceptions,
    catch (...) {

        //  and output a message saying that the code temrinated abruptly
        //  due to an uncaught exception.
        std::cerr << " The code temrinated abruptly (other). " << std::endl;
    }

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu